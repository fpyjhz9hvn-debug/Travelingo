/*
 * House (phosphor-icons/House@0.0.53)
 *
 * Learn More: https://www.framer.com/asset-urls
 */

export * from "https://framerusercontent.com/modules/Qc8yuHkQmGO0kFiSWbkX/i6WSiDLftYVS2GvUElTz/House.js"
export { default } from "https://framerusercontent.com/modules/Qc8yuHkQmGO0kFiSWbkX/i6WSiDLftYVS2GvUElTz/House.js"
