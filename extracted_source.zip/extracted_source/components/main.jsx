
		import * as Framer from "framer";
import * as React from "react";
import { createPortal } from "react-dom";
import * as ReactDOM from "react-dom/client";
import Template1 from "https://framerusercontent.com/modules/7IhA2UAajwAitgkqRdO1/ERtjZaBjwrRz6tkQWr0i/YnuFzCONs.js";

		const routes = {JkttCZZxP: {elements: {hKUHthd4D: "out-1", hrLn9MijH: "in-2", IAxMQQnKk: "out-2", ikiS5XUAF: "out-3", kp8CY609m: "hero", meuuD4H_m: "switch-2", quIWp9ZKV: "switch-4", uLs23mei7: "intro", vl_DINdog: "in-3", xeawFPDAl: "in-4", zcnMabeoz: "switch-3"}, page: Framer.lazy(() => import("https://framerusercontent.com/modules/QgT2X2RCkVIBeQJ6FqsM/s6oadhL7UAXe7XNOjvYn/JkttCZZxP.js")), path: "/"}, g4oChqUxB: {elements: {}, page: Framer.lazy(() => import("https://framerusercontent.com/modules/bjrmRqP0UMBAg5Q0s9Rm/3aYQufEuvpEZUosoiWUb/g4oChqUxB.js")), path: "/404"}, Y7F3jmm6j: {elements: {}, page: Framer.lazy(() => import("https://framerusercontent.com/modules/EpmF3Bbk3B4Eybqjr6PO/A7UKoiceFVIs3GJMRdUu/Y7F3jmm6j.js")), path: "/book-a-trip"}, AzLeNw7Sc: {elements: {}, page: Framer.lazy(() => import("https://framerusercontent.com/modules/ipxQoR0OAIIJGKuQ3AZu/dPk2rfrIqUVocQ60RCIl/AzLeNw7Sc.js")), path: "/about"}, MisDGWCy9: {elements: {}, page: Framer.lazy(() => import("https://framerusercontent.com/modules/JvmAeIg63Ap2vTyj99UG/kJlwK8LLNmoNQmOaJqPa/MisDGWCy9.js")), path: "/blogs"}, KOLcB4LlH: {elements: {}, page: Framer.lazy(() => import("https://framerusercontent.com/modules/sJVrMTDZUevYD1fX0J30/Wu06iifoPRcZYhr2Qy6h/KOLcB4LlH.js")), path: "/tours"}, NZTsQ8Sfo: {collectionId: "ofgUd8RAs", elements: {}, page: Framer.lazy(() => import("https://framerusercontent.com/modules/s70SYSNvJAImf8U8KIJL/hBV7kFOV6eTpqC2SxyxF/NZTsQ8Sfo.js")), path: "/tours/:ffrqBkpLP"}, GyTaKLM2w: {collectionId: "ysqa11MKy", elements: {}, page: Framer.lazy(() => import("https://framerusercontent.com/modules/bhjzUgZl2Dcyoc8vvSyU/zAs7XZXbawLS7fTulJrw/GyTaKLM2w.js")), path: "/destinations/:N6ZbQXHdN"}, x0URXFwG2: {collectionId: "VR8dW1t5O", elements: {}, page: Framer.lazy(() => import("https://framerusercontent.com/modules/GDkvxHgBfovuGtDjd07Q/5x6fGPDFenj37Fc9azPP/x0URXFwG2.js")), path: "/activities/:wJeWQBqmm"}, cnnBCQ5Sh: {collectionId: "BymTlK1Lu", elements: {uOhoLD_yR: "content"}, page: Framer.lazy(() => import("https://framerusercontent.com/modules/XCLqNHYXouRiLQe8Yj21/Bh6QdPfVdCHLlj1NNdxK/cnnBCQ5Sh.js")), path: "/blogs/:d3sA62O78"}, oPHqgtg8c: {collectionId: "fFfyRiei6", elements: {}, page: Framer.lazy(() => import("https://framerusercontent.com/modules/C91j7YgDQXdjUZfopqQq/k2Pb5G9hSWL78uhE5rLg/oPHqgtg8c.js")), path: "/policies/:jDbyqghgM"}}

		const locales = [{code: "en-IN", id: "default", name: "English", slug: "", textDirection: "ltr"}]
		const collectionUtils = {BymTlK1Lu: async () => (await import("https://framerusercontent.com/modules/rdZBt50reVzB7gKcpWbX/EQ0eG9Mp9Zni2qU2SU10/BymTlK1Lu.js"))?.["utils"], fFfyRiei6: async () => (await import("https://framerusercontent.com/modules/BuBDwK4vKG8te83WhcNi/PoPq2rFmMKdbrIsHB1qc/fFfyRiei6.js"))?.["utils"], ofgUd8RAs: async () => (await import("https://framerusercontent.com/modules/ozKxTfp7RRIudfLLTEpl/6oldpmpXdKFpTlHzhxua/ofgUd8RAs.js"))?.["utils"], VR8dW1t5O: async () => (await import("https://framerusercontent.com/modules/sPb9YCuuBWgqFLwYBmAa/qdQvFD07bByrrvS21b2q/VR8dW1t5O.js"))?.["utils"], ysqa11MKy: async () => (await import("https://framerusercontent.com/modules/3mjsWf3LtD3QGjjKNrGO/3peSJjuruHu61SIvZ6xI/ysqa11MKy.js"))?.["utils"]}
		const serverDatabaseClient = undefined
		const framerSiteId = "5be5a1e1ec03b08fd1532d58fe05347a53670ba215f8f41010538eca4def7511"
		function Template({webPageId, children, style, ...rest}) {const templateProps = {}
const props = templateProps[webPageId] ?? {}
switch (webPageId) {case "JkttCZZxP":
case "g4oChqUxB":
case "Y7F3jmm6j":
case "AzLeNw7Sc":
case "MisDGWCy9":
case "KOLcB4LlH":
case "NZTsQ8Sfo":
case "GyTaKLM2w":
case "x0URXFwG2":
case "cnnBCQ5Sh":
case "oPHqgtg8c":
return React.createElement(Template1, {...props, key: "Template1", style}, children(true));
default: { return children(false) }}}
export function getLayoutTemplateBreakpoints(routeId) {switch (routeId) {case "JkttCZZxP":
case "g4oChqUxB":
case "Y7F3jmm6j":
case "AzLeNw7Sc":
case "MisDGWCy9":
case "KOLcB4LlH":
case "NZTsQ8Sfo":
case "GyTaKLM2w":
case "x0URXFwG2":
case "cnnBCQ5Sh":
case "oPHqgtg8c":
return [{hash: "osn5lw", mediaQuery: "(min-width: 1200px)"}, {hash: "1srwj7w", mediaQuery: "(min-width: 810px) and (max-width: 1199.98px)"}, {hash: "90xs6c", mediaQuery: "(max-width: 809.98px)"}]
default: { return undefined }}}

		const isBrowser = typeof document !== "undefined"
		const isBot = isBrowser && /bot|-google|google-|yandex|ia_archiver|crawl|spider/iu.test(navigator.userAgent)

		
		

		export async function getPageRoot({
			routeId,
			pathVariables,
			canonicalPathVariables,
			localeId,
			collectionItemId,
			contentLocaleId,
			shouldResolveInitialRouteContentState = false,
		}) {
			const rootPreload = routes[routeId].page.preload()

			

			Framer.setLibraryFeatures({checkServerSideRouter: true, disableCustomCode: false, disableHoverOnMobile: false, editorBarDisableFrameAncestorsSecurity: false, motionDivToDiv: false, onPageLocalizationSupport: true, onPageMoveTool: true, onPageRichTextBlockSelection: true, scrollRestoration: true, synchronousNavigationOnDesktop: false, yieldOnTap: false})
			Framer.setCurrentSiteId(framerSiteId)

			const content = React.createElement(
				Framer.PageRoot,
				{
					isWebsite: true,
					environment: "site",
					routeId,
					pathVariables,
					canonicalPathVariables,
					routes,
					collectionUtils,
					serverDatabaseClient,
					framerSiteId,
					notFoundPage: Framer.lazy(() => import("https://framerusercontent.com/modules/bjrmRqP0UMBAg5Q0s9Rm/3aYQufEuvpEZUosoiWUb/g4oChqUxB.js")),
					isReducedMotion: undefined,
					localeId,
					locales,
					preserveQueryParams: undefined,
					siteCanonicalURL: "https://traavellio.framer.website",
					EditorBar: 
			typeof window !== "undefined" ? (() => {
				if (isBot) {
					console.log("[Framer On-Page Editing] Unavailable because navigator is bot")
					return
				}

				return Framer.lazy(async () => {
					const dependencies = {
						__version: 3,
						framer: {
							useCurrentRoute: Framer.useCurrentRoute,
							useLocaleInfo: Framer.useLocaleInfo,
							useRouter: Framer.useRouter,
						},
						react: {
							createElement: React.createElement,
							Fragment: React.Fragment,
							memo: React.memo,
							useCallback: React.useCallback,
							useEffect: React.useEffect,
							useRef: React.useRef,
							useState: React.useState,
							useLayoutEffect: React.useLayoutEffect,
						},
						"react-dom": { createPortal },
					}

					window.__framer_editorBarDependencies = dependencies

					const { createEditorBar } = await import("https://framer.com/edit/init.mjs")
					return {
						default: createEditorBar(),
					}
				})
			})() : undefined
		,
					adaptLayoutToTextDirection: true,
					LayoutTemplate: Template,
					loadSnippetsModule: new Framer.LazyValue(() => import("https://framerusercontent.com/modules/pLm1ema8RatKw5eKHDi1/oPdDsVc3s5p7O9Mv6sUD/snippets.js")),
					initialCollectionItemId: collectionItemId,
					initialContentLocaleIdOverride: contentLocaleId,
				}
			)

			const contentWithGracefullyDegradingErrorBoundary = React.createElement(Framer.GracefullyDegradingErrorBoundary, {
				children: content
			})

			
			const page = React.createElement(Framer.PageEffectsProvider, {
				children: contentWithGracefullyDegradingErrorBoundary,
				value: {global: {enter: {mask: {type: "circle", x: "50%", y: "50%"}, opacity: 0, rotate: 0, rotate3d: false, rotateX: 0, rotateY: 0, scale: 1, transition: {damping: 30, delay: 0, duration: 0.2, ease: [0.27, 0, 0.51, 1], mass: 1, stiffness: 400, type: "tween"}, x: "0px", y: "0px"}}, routes: {}}
			})

			// We don't want the initial render to immediately have to suspend.
			await rootPreload
			return page
		}
	

		if (isBrowser) {
			// Note: HTTPArchive also uses this function to detect Framer sites; see https://github.com/HTTPArchive/wappalyzer/blob/371a17583f74fd9171b9077f59a5619b24062891/src/technologies/f.json#L1722-L1748.
			window.__framer_importFromPackage = (packageAndFilename, exportIdentifier) => () => {
				return React.createElement(Framer.ErrorPlaceholder, { error: 'Package component not supported: "' + exportIdentifier + '" in "' + packageAndFilename + '"' })
			}

			window.__framer_events = window.__framer_events || []

			// Initialize lazy modules cache for hydration
			Framer.initLazyModulesCache()

			const container = document.getElementById("main")
			// We know that #main is parsed before this script, so we don't need to wait for DOMContentLoaded or similar events.
			if ("framerHydrateV2" in container.dataset) main(true, container)
			else main(false, container)
		}

		function track() {
			if (!isBrowser) return
			window.__framer_events.push(arguments)
		}

		async function main(shouldHydrate, container) {
			function handleError(error, errorInfo, recoverable = true) {
				if (error.caught || window.__framer_hadFatalError) return // we already logged it

				const componentStack = errorInfo?.componentStack
				if (recoverable) {
					console.warn("Caught a recoverable error. The site is still functional, but might have some UI flickering or degraded page load performance. If you are the author of this website, update external components and check recently added custom code or code overrides to fix the following server/client mismatches:\n", error, componentStack)
					// we only want to collect 1%, because this can be quite noisy (floods the data pipeline)
					if (Math.random() > 0.01) return
				} else {
					console.error("Caught a fatal error. Please report the following to the Framer team via https://www.framer.com/contact/:\n", error, componentStack)
				}
				track(recoverable ? "published_site_load_recoverable_error" : "published_site_load_error", {
					message: String(error),
					componentStack, // componentStack is more useful
					stack: componentStack ? undefined : error instanceof Error && typeof error.stack === "string" ? error.stack : null,
				})
			}

			try {
				let routeId, localeId, contentLocaleId, pathVariables, canonicalPathVariables, breakpoints, routeData
				if (shouldHydrate) {
					routeData = JSON.parse(container.dataset["framerHydrateV2"])
					routeId = routeData.routeId
					localeId = routeData.localeId
					contentLocaleId = routeData.contentLocaleId
					pathVariables = routeData.pathVariables
					canonicalPathVariables = routeData.canonicalPathVariables
					breakpoints = routeData.breakpoints

					routeId = Framer.patchRoutesForABTesting(routes, routeId) // Prioritize optimized route id to avoid flickering in browsers not supporting the server-timing header (Safari older than 16.4)
				} else {
					Framer.patchRoutesForABTesting(routes, undefined) // This must happen before inferInitialRouteFromPath

					
					const serverRoute = performance.getEntriesByType("navigation")[0]?.serverTiming?.find(e => e.name === "route")?.description
					if (serverRoute) {
						const routeData = new URLSearchParams(serverRoute)
						routeId = routeData.get("id")
						localeId = routeData.get("locale")
						for (const [key, value] of routeData.entries()) {
							if (!key.startsWith("var.")) continue
							pathVariables ??= {}
							pathVariables[key.slice(4)] = value
						}
					}
					if (!routeId || !localeId) {
						const routeData = Framer.inferInitialRouteFromPath(routes, decodeURIComponent(location.pathname), true, locales)
						routeId = routeData.routeId
						localeId = routeData.localeId
						pathVariables = routeData.pathVariables
					}
					
				}

				const pagePromise = getPageRoot({
					routeId,
					localeId,
					contentLocaleId,
					pathVariables,
					canonicalPathVariables,
					collectionItemId: shouldHydrate ? routeData?.collectionItemId : undefined,
					shouldResolveInitialRouteContentState: !shouldHydrate,
				})

				
if (typeof window !== "undefined") {
	void (async () => {
		const route = routes[routeId]

		const defaultLocaleId = "default"
		const framerLocale = locales.find(({ id }) => !localeId ? id === defaultLocaleId : id === localeId).code

		
		let collectionItemId = routeData?.collectionItemId ?? null
		if (collectionItemId === null && route?.collectionId && collectionUtils) {
			const utils = await collectionUtils[route.collectionId]?.()
			const [slug] = Object.values(pathVariables)
			if (utils && typeof slug === "string") {
				collectionItemId = (await utils.getRecordIdBySlug(slug, framerLocale || undefined)) ?? null
			}
		}
	

		const resolvedDateTimeOptions = Intl.DateTimeFormat().resolvedOptions()
		const timezone = resolvedDateTimeOptions.timeZone
		const locale = resolvedDateTimeOptions.locale

		// wait for the page to be activated before sending the pageview event
		// https://developer.chrome.com/docs/web-platform/prerender-pages#impact-on-analytics
		await new Promise((resolve) => {
			if (document.prerendering) {
				document.addEventListener("prerenderingchange", resolve, { once: true })
			} else {
				resolve()
			}
		})

		window.__framer_events.push([
			"published_site_pageview",
			{
				framerSiteId,
				version: 2,
				routePath: route?.path || "/",
				collectionItemId,
				framerLocale: framerLocale || null,
				webPageId: route?.abTestingVariantId ?? routeId,
				abTestId: route?.abTestId,
				referrer: document.referrer || null,
				url: window.location.href,
				hostname: window.location.hostname || null,
				pathname: window.location.pathname || null,
				hash: window.location.hash || null,
				search: window.location.search || null,
				timezone,
				locale,
			},
			"eager"
		])

		// Yield to avoid blocking the main thread with the user code
		await Framer.yieldToMain({ priority: "background", ensureContinueBeforeUnload: true, continueAfter: "paint" })

		document.dispatchEvent(new CustomEvent("framer:pageview", {
			detail: { framerLocale: framerLocale || null }
		}))
	})()
}


				const page = await pagePromise
				if (shouldHydrate) {
					

					Framer.withPerformanceMarks("framer-rewrite-breakpoints", () => {
						Framer.removeHiddenBreakpointLayersV2(breakpoints)
						window.__framer_onRewriteBreakpoints?.(breakpoints)
					})

					

					const startTransition = isBot ? cb => cb() : React.startTransition
					startTransition(() => {
						Framer.markHydrationStart()
						Framer.turnOffReactEventHandling()
						ReactDOM.hydrateRoot(container, page, { onRecoverableError: handleError })
					})
				} else {
					
					ReactDOM.createRoot(container, { onRecoverableError: handleError }).render(page)
				}
			} catch (error) {
				handleError(error, undefined, false)
				throw error
			}
		}

		

		
		;(function () {
			if (!isBrowser) return

			React.startTransition(() => {
				ReactDOM.hydrateRoot(
					document.getElementById("__framer-badge-container"),
					React.createElement(React.Suspense, {}, React.createElement(React.lazy(() => import("__framer-badge"))))
				)
			})
		})()
	